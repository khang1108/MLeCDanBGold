"""Bounded AI components."""
